let sum = (a, b) => {
  return a + b + 'sum';
}

let minus = (a, b) => {
  return a - b + 'minus';
}

export default {
  sum, minus
}